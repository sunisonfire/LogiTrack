package com.DannaS2.LogiTrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogiTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
