package com.DannaS2.LogiTrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogiTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogiTrackApplication.class, args);
		System.out.print("Hola");
	}

}
